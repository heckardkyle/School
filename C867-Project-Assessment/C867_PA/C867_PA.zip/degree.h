#ifndef DEGREE_H
#define DEGREE_H

#include <iostream>
#include <string>
using namespace std;

enum Degree { SECURITY, NETWORKING, SOFTWARE };
static const string degreeStrings[] = { "SECURITY", "NETWORKING", "SOFTWARE" };

#endif
